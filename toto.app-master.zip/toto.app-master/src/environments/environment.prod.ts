export const environment = {
  production: true,
  api : 'http://139.59.253.0/202951640132/api/', 
  base_url : 'http://139.59.253.0/202951640132/totoadmin/',

  //api : 'https://bintangpantura.xyz/api/', 
 // base_url : 'https://bintangpantura.xyz/totoadmin/',

  //  api : 'http://demogames.linkbamboo.com/api/', 
  //base_url : 'http://demogames.linkbamboo.com/admin1/',

  apiKey: 'cc5hqwaiqsocbfakkn5qpug7r9bx5zioxppbw9h6w4gd0286',
  tinyConfig: {
    height: 500,
    menubar: 'table',
    plugins: [
      'advlist autolink lists link image charmap print preview anchor image table',
      'searchreplace visualblocks code ',
      'insertdatetime media table paste code wordcount'
    ],
    toolbar:
      'undo redo | formatselect | bold italic backcolor | \
    alignleft aligncenter alignright alignjustify | image  | \
    bullist numlist outdent indent | removeformat | code'
  }
};
