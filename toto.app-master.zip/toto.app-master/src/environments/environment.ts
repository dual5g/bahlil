export const environment = {
  production: false,
  api: 'http://localhost/website/toto/api/',
  base_url: 'http://localhost:4200/',
  apiKey: 'cc5hqwaiqsocbfakkn5qpug7r9bx5zioxppbw9h6w4gd0286',
  tinyConfig: {
    height: 500,
    menubar: 'table',
    plugins: [
      'advlist autolink lists link image charmap print preview anchor image table',
      'searchreplace visualblocks code ',
      'insertdatetime media table paste code wordcount'
    ],
    toolbar:
      'undo redo | formatselect | bold italic backcolor | \
    alignleft aligncenter alignright alignjustify | image  | \
    bullist numlist outdent indent | removeformat | code'
  }

  // api : 'https://admin.totogames.top/api/', 
  // base_url : 'https://admin.totogames.top/dist/'
};
