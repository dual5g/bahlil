import { Component, OnInit, Input, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ConfigService } from 'src/app/service/config.service';
import { environment } from 'src/environments/environment';
import { NgxSpinnerService } from "ngx-spinner";
import * as Feather from 'feather-icons';

declare var $;
@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.scss']
})
export class WithdrawComponent implements OnInit {
  onEmit: EventEmitter<boolean> = new EventEmitter();


  items: any = [];

  id: string;
  currency: string = "Rp ";
  constructor(
    private http: HttpClient,
    private configService: ConfigService,
    private spinner: NgxSpinnerService
  ) { }

  ngOnInit(): void {
    Feather.replace(); 
    this.httpGet();
  }

  access(){
    return this.configService.accessRight("4");
  }
  
  update(){
    return this.configService.accessRight("1")['_update'];
  }

  httpGet() {
    this.spinner.show();
    this.http.get<any>(environment.api + 'withdraw/', {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        console.log(data);
        this.items = data['data'];
        this.spinner.hide();
      }, error => {
        console.log(error);
        this.spinner.hide();
      })
  }

  onWithdrawApproved(obj, approved, status) {
    const body = {
      data: obj,
      approved: approved
    }
    if (confirm(status + " " + obj.username + " ?")) {


      this.http.post<any>(environment.api + 'transaction/onWithdrawApproved/' + obj.id, body, {
        headers: this.configService.headers()
      }).subscribe(
        data => {
          this.httpGet();
          this.onEmit.emit(true);
          console.log(data);
        }, error => {
          console.log(error);
        })

    }
  }
}
