import { Component, OnInit, HostListener } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PlatformLocation } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { ConfigService } from 'src/app/service/config.service';
import { environment } from 'src/environments/environment';

import { NgxSpinnerService } from "ngx-spinner";
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import * as Feather from 'feather-icons';

declare var $;
@Component({
  selector: 'app-input',
  templateUrl: './input.component.html',
  styleUrls: ['./input.component.scss']
})
export class InputComponent implements OnInit {
  items: any = [];
  games: any = [];
  id: string;
  currency: string = "Rp ";
  market: any = [];
  inputResult: boolean = false;
  loading: boolean = false;
  finalResult: any = [];
  updateSuccess: boolean = false;
  updateDate : boolean =false;
  constructor(
    private http: HttpClient,
    private router: Router,
    private configService: ConfigService,
    private activatedRoute: ActivatedRoute,
    location: PlatformLocation,
    config: NgbModalConfig, private modalService: NgbModal,
    private spinner: NgxSpinnerService,
  ) {
    location.onPopState(() => {
      $('.modal').modal('hide');
    });
    config.backdrop = 'static';
    config.keyboard = false;
  }

  ngOnInit(): void {
    Feather.replace();
    this.httpGet();
  }

  httpGet() {
    this.spinner.show();
    this.http.get<any>(environment.api + 'result/', {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        console.log(data);
        this.items = data['data'];
        this.games = data['games'];
        this.spinner.hide();
      }, error => {
        console.log(error);
        this.spinner.hide();
      })
  }

  onModal(market) {
    this.market = market;
  }

  onSimulation(i, obj) {
    this.http.post<any>(environment.api + 'result/onSimulation', obj, {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        console.log(data);
        this.items[i]['totalWinSim'] = data['win'];
        this.items[i]['totalLoseSim'] = data['lose'];
      }, error => {
        console.log(error);
      });
  }

  open(content) {
    const data = this.items.map(elm => ({
      name: elm['name'],
      marketId: elm['id'],
      periodNumber: elm['periodNumber'],
      periodDate: elm['periodDate'], 
      totalNumber: elm['totalNumber'],
      periodId: elm['periodId'],
      result: String(elm['result']).length >= 4 ? elm['result'] : null,
      pending : elm['pending'],
      icon : elm['icon']
    }));
    console.log(data);
    this.finalResult = data;
    this.modalService.open(content, { size: 'xl' });
  }


  onSubmitResult() {
   
      this.loading = true;
 
      this.http.post<any>(environment.api + 'result/onSubmitResult/', this.items, {
        headers: this.configService.headers()
      }).subscribe(
        data => {
          console.log(data);
          this.loading = false;
          this.updateSuccess = true;
         // this.router.navigate(['period']);
        }, error => {
          this.loading = false;
          console.log(error);
          alert("Error Server ! onSubmitResult(); ");
         // window.location.reload();
         
        });
    
  }

  onRefresh(){
    window.location.reload();
  }


  onTestNewPeroid() {
    this.loading = true;
    this.http.post<any>(environment.api + 'result/onTestNewPeroid/', this.items, {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        console.log(data);
        this.loading = false;
      }, error => {
        this.loading = false;
        alert("Error Server ! onTestNewPeroid(); ");
        console.log(error);
      })
  }

  onChangesDate(obj) {
    console.log(obj);

    // periodDate: "2021-08-29 18:06:00"
    // periodId: "188"
    this.http.post<any>(environment.api + 'result/onChangesDate/', obj, {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        console.log(data); 
        this.updateDate=false;
      }, error => {
        this.loading = false;
        alert("Error Server ! onChangesDate(); "); 
        console.log(error);
      })


  }
}
