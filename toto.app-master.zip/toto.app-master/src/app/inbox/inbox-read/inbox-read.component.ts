import { Component, OnInit, HostListener } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PlatformLocation } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { ConfigService } from 'src/app/service/config.service';
import { environment } from 'src/environments/environment';

import { NgxSpinnerService } from "ngx-spinner";
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import * as Feather from 'feather-icons';

declare var $;


export class Reply {

  constructor(
    public title: string,
    public message: string,

  ) { }

}

@Component({
  selector: 'app-inbox-read',
  templateUrl: './inbox-read.component.html',
  styleUrls: ['./inbox-read.component.scss']
})
export class InboxReadComponent implements OnInit {
  items: any = [];
  uuid: string;
  lastId: string;
  subject: string;
  reply: any = new Reply("", "");
  constructor(
    private http: HttpClient,
    private router: Router,
    private configService: ConfigService,
    private activatedRoute: ActivatedRoute,
    location: PlatformLocation,
    config: NgbModalConfig, private modalService: NgbModal,
    private spinner: NgxSpinnerService,
  ) { }

  ngOnInit(): void {
    Feather.replace();

    this.uuid = this.activatedRoute.snapshot.paramMap.get('uuid');
    this.httpGet(this.uuid);

  }


  httpGet(uuid: string) {
    this.spinner.show();
    this.http.get<any>(environment.api + 'inbox/read/' + uuid, {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        this.items = data['data'];
        this.lastId = data['lastId'];
        this.subject = data['subject'];
        console.log(data);
        this.spinner.hide();
      }, error => {
        console.log(error);
        this.spinner.hide();
      })
  }

  onSubmit() {
    this.spinner.show();
    const body = {
      uuid: this.uuid,
      reply: this.reply
    }
    this.http.post<any>(environment.api + 'inbox/onSubmit/', body, {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        this.httpGet(this.uuid);
        console.log(data);
        this.reply = "";
      }, error => {
        console.log(error);
        alert("Error! On Submit");
        this.spinner.hide();
      })
  }
}
