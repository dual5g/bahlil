import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ConfigService } from 'src/app/service/config.service';
import { environment } from 'src/environments/environment';

import * as $ from 'jquery';
import * as Feather from 'feather-icons';
import { NgxSpinnerService } from 'ngx-spinner';


declare var $;

@Component({
  selector: 'app-inbox',
  templateUrl: './inbox.component.html',
  styleUrls: ['./inbox.component.scss']
})
export class InboxComponent implements OnInit {
  items: any = [];
  constructor(
    private http: HttpClient,
    private router: Router,
    private configService: ConfigService,
    private spinner: NgxSpinnerService
  ) { }

  ngOnInit(): void {
    Feather.replace();
    //this.dataTabel();
    this.httpGet();
  }
  


  httpGet() {
    this.spinner.show();
    this.http.get<any>(environment.api + "inbox/index/", {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        console.log(data);
        this.items = data['data']; 
        this.spinner.hide();
        $(document).ready(function () {
          $.fn.dataTable.ext.errMode = 'none';
          $('#dtable').DataTable(
            { "bSort": false },
          );
        });
      }, error => {
        console.log(error);
        this.spinner.hide();
      })
  }

  remove(obj){
    this.spinner.show();
    this.http.post<any>(environment.api + "inbox/remove/",obj, {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        console.log(data); 
       
          this.router.navigateByUrl('/', {skipLocationChange: true}).then(()=>
          this.router.navigate(['inbox'])); 
      }, error => {
        console.log(error);
        this.spinner.hide();
      })
  }


  dataTabel() {
    var self = this;
    var currency = "Rp ";
    $(document).ready(function () {

      $('#dtable').DataTable({
        ajax: {
          url: environment.api + "inbox/index/",
          type: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Key': self.configService.key(),
            'Token': self.configService.token(),
          },

        },
        aoColumnDefs: [{ "asSorting": false, "aTargets": [0] }],
        lengthMenu: [50, 100, 200],
        "language": {
          "decimal": ",",
          "thousands": "."
        },
        order: [[3, "desc"]],
        columnDefs: [
          {
            "targets": 0,
            "render": function (data, type, row, meta) {
              return '<a class="text-dark" href="#/inbox/read/' + row[0] + '">' + row[4] + '</a>';
            },
            createdCell: function (td, cellData, rowData, row, col) {
              if (rowData[6] == '1') {
                $(td).css('background', '#F3F4F7');
              }
            }
          },


          {
            "targets": 1,
            "render": function (data, type, row, meta) {
              return '<a class="text-dark" href="#/inbox/read/' + row[0] + '">' + row[1] + '</a>' + '<div class="py-1">' + row[2] + '<div>';
            },
            createdCell: function (td, cellData, rowData, row, col) {
              if (rowData[6] == '1') {
                $(td).css('background', '#F3F4F7');
              }
            }
          },

          {
            "targets": 2,
            "render": function (data, type, row, meta) {
              return '<a class="text-dark" href="#/inbox/read/' + row[0] + '">' + row[3] + '</a>';
            },
            createdCell: function (td, cellData, rowData, row, col) {
              if (rowData[6] == '1') {
                $(td).css('background', '#F3F4F7');
              }
            }
          },

          {
            "targets": 3,
            "render": function (data, type, row, meta) {
              return '<a class="text-dark" href="#/inbox/read/' + row[0] + '">' + row[5] + '</a>';
            },
            createdCell: function (td, cellData, rowData, row, col) {
              if (rowData[6] == '1') {
                $(td).css('background', '#F3F4F7');
              }
            }
          },

          {
            "targets": 4,
            "render": function (data, type, row, meta) {
              return '<a class="text-dark" href="javascript:;" (click)="remove("1")">Remove</a>';
            },
            createdCell: function (td, cellData, rowData, row, col) {
              if (rowData[6] == '1') {
                $(td).css('background', '#F3F4F7');
              }
            }
          },


        ],

      });
    });
  }

}
