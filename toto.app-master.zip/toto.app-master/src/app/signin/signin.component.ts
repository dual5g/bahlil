import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { CookiesService } from 'src/app/service/cookies.service';
import { NgxSpinnerService } from "ngx-spinner";

export class Login {
  constructor(
    public email: string,
    public password: string,
    public device: string
  ) { }
}

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {
  result: string;
  model: any = new Login('', '', 'website');
  year: number = new Date().getFullYear();
  constructor(
    private http: HttpClient,
    private router: Router,
    private cookies: CookiesService,
    private spinner: NgxSpinnerService
  ) { }

  ngOnInit(): void {
    this.isSignin(); 
  }

  isSignin() { 
    if (this.cookies.getCookie('totoBamboV1') && this.cookies.getCookie('totoBamboV1Access')) {
      window.location.href= environment.base_url+ '/#/dashboard'; 
    }
  }

  onSubmit() {
    this.spinner.show();
    this.http.post<any>(environment.api + 'login/signin', this.model).subscribe(
      data => {
        this.spinner.hide();
        console.log(data);
        this.result = data['data']['login'] ? "Login Success..." : "Wrong login";
        if (data['data']['login'] == true) {
          this.cookies.setCookie('totoBamboV1', data['data']['token'], 1); 
          this.cookies.setCookie('totoBamboV1Access', data['data']['userAccess'], 1); 
          
          window.location.href=  environment.base_url+ '#/dashboard'; 
        }
        this.spinner.hide();
      }, error => {
        console.log(error);
        this.spinner.hide();
      })

  }
}
