import { Component, OnInit, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { ConfigService } from 'src/app/service/config.service';
import { environment } from 'src/environments/environment';
import { NgxSpinnerService } from "ngx-spinner";
import * as Feather from 'feather-icons'; 

declare var $;
 
@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.scss']
})
export class DepositComponent implements OnInit {
  onEmit: EventEmitter<boolean> = new EventEmitter();


  items: any = []; 
  
  id:string;
  currency : string = "Rp ";
  constructor(
    private http: HttpClient,
    private router: Router,
    private configService: ConfigService,
    private activatedRoute: ActivatedRoute,
    private spinner: NgxSpinnerService
  ) { }

  ngOnInit(): void { 
    Feather.replace();
    this.httpGet(); 
  }

  httpGet() {
    this.spinner.show();
    this.http.get<any>( environment.api+'deposit/',{
      headers: this.configService.headers()
    }).subscribe(
      data=>{ 
        this.items = data['data'];   
        this.spinner.hide();
      },error=>{
        console.log(error);
        alert("Error Server Connection !");
        this.spinner.hide();
      })
  }
  update(){
    return this.configService.accessRight("2")['_update'];
  }
  onTopupApproved(obj, approved, status) {
    if( confirm( status + " "+obj.username+"? ")){
      this.spinner.show();
      const body = {
        data: obj,
        approved: approved
      }
      console.log(body);
      this.http.post<any>(environment.api + 'transaction/onTopupApproved/' + obj.id, body, {
        headers: this.configService.headers()
      }).subscribe(
        data => {
          this.httpGet();
          this.onEmit.emit(true);
          console.log(data);
        }, error => {
          alert("Error Server Connection !");
          console.log(error);
          
        })
    }
   
  }
  

  
}
