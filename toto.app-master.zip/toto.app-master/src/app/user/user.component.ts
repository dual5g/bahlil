import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ConfigService } from 'src/app/service/config.service';
import { environment } from 'src/environments/environment';  

import { NgxSpinnerService } from "ngx-spinner";

import * as $ from 'jquery';
import * as Feather from 'feather-icons';


declare var $;
 

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})
export class UserComponent implements OnInit {
  
  items: any = [];
  constructor(
    private http: HttpClient,
    private router: Router,
    private configService: ConfigService,
    
    private spinner: NgxSpinnerService
  ) { }

  ngOnInit(): void {
    Feather.replace(); 
   
    this.httpGet(); 
  }

  httpGet() {
    this.spinner.show();
    this.http.get<any>(environment.api + 'user/index/1', {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        console.log(data);
        this.spinner.hide();
        this.items = data['user']; 
        $(document).ready(function () { 
          $('.dtable').DataTable( 
            { "bSort" : false }, 
          );
        }); 
      }, error => {
        console.log(error);
        this.spinner.hide();
        alert("Error Server Connection !");
      })
  }
 
}
