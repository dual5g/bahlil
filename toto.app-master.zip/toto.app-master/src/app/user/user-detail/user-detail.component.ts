import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { ConfigService } from 'src/app/service/config.service';
import { environment } from 'src/environments/environment';
import { NgxSpinnerService } from "ngx-spinner";
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import {Md5} from "md5-typescript";
import * as Feather from 'feather-icons';
import * as $ from 'jquery'; 


declare var $;
 
export class Balance {

  constructor(
    public amount: string,
    public note: string,
  ) { }

}

@Component({
  selector: 'app-user-detail',
  templateUrl: './user-detail.component.html',
  styleUrls: ['./user-detail.component.scss']
})
export class UserDetailComponent implements OnInit {
  transaction: any = [];
  user: any = [];
  info: any = [];
  topup: any = [];
  withdraw: any = [];
  balance: any = new Balance("0", "");
  id: string;
  currency: string = "Rp ";
  showAddBalance : boolean = false;
  reasonBlock : string;
  user_auth : any = [];
  password : string;
  resetPasswordNoEmail : boolean= false;
  constructor(
    private http: HttpClient,
    private router: Router,
    private configService: ConfigService,
    private activatedRoute: ActivatedRoute,
    private spinner: NgxSpinnerService,
    config: NgbModalConfig, private modalService: NgbModal
  ) { 
    config.backdrop = 'static';
    config.keyboard = false;
  }

  ngOnInit(): void {

    this.id = this.activatedRoute.snapshot.paramMap.get('id');
    Feather.replace();
    this.httpGet(this.id);
  }

  httpGet(id) {
    this.spinner.show();
    this.http.get<any>(environment.api + 'transaction/user/' + id, {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        console.log(data);
        this.user = data['user'];
        this.transaction = data['transaction'];
        this.info = data['info'];
        this.topup = data['topup'];
        this.withdraw = data['withdraw'];
        this.user_auth = data['user_auth'];
        $(document).ready(function () { 
          $('.dataTable').DataTable(
            { "bSort": false },
          );
        });
 
        this.spinner.hide();
      }, error => {
        console.log(error);
        this.spinner.hide();
      })
  }


  reload(id) {
    this.spinner.show();
    this.http.get<any>(environment.api + 'transaction/user/' + id, {
      headers: this.configService.headers()
    }).subscribe(
      data => {
 
        this.user = data['user']; 
        this.info = data['info']; 
        this.user_auth = data['user_auth'];
  
        this.spinner.hide();
      }, error => {
        console.log(error);
        this.spinner.hide();
      })
  }

  onSubmitBalance() {
    if (this.balance['amount'] != "0") { 
      this.spinner.show();
      const body = {
        userId: this.id,
        balance: this.balance,
      }
      this.http.post<any>(environment.api + 'transaction/onSubmitBalance/', body, {
        headers: this.configService.headers()
      }).subscribe(
        data => {
          console.log(data);
          this.httpGet(this.id);
          this.showAddBalance = false;
          this.balance = new Balance("0", "");
          this.spinner.hide();
        }, error => {
          console.log(error);
          this.spinner.hide();
        });
    }
  }

  remove(){
    if (confirm("Delete " + this.user['username'] + " ?")) {
      this.spinner.show();
      const body = {
        id: this.id, 
      }
      this.http.post<any>(environment.api + 'user/remove/', body, {
        headers: this.configService.headers()
      }).subscribe(
        () => { 
          this.router.navigate(['/user']);
        }, error => {
          alert("ERROR REMOVE()"); 
          this.spinner.hide();
          console.log(error);
        })

   
    }
  }

  block(id, status) {
    if (confirm("Block  " + this.user['username'] + " ?")) {
      const body = {
        id: id,
        status: status,
        reasonBlock : this.reasonBlock ? this.reasonBlock : "" ,
      }
      this.spinner.show();
      this.http.post<any>(environment.api + 'user/onBlock/', body, {
        headers: this.configService.headers()
      }).subscribe(
        data => { 
          console.log(data);
          this.reload(this.id);
        }, error => {
          alert("ERROR BLOCK()");
          
          this.spinner.hide();
          console.log(error);
        })
    }


  }


  resetPassword(){
    if (confirm("Resert password  " + this.user['username'] + " ?")) {
      this.spinner.show();
      const body = {
        password: Md5.init(this.password), 
        id : this.id,
      }
      this.http.post<any>(environment.api + 'user/resetPassword/', body, {
        headers: this.configService.headers()
      }).subscribe(
        data => { 
          console.log(data);
          alert("Password already change.");
          this.spinner.hide();
        }, error => {
          alert("ERROR RESETPASSWORD()"); 
          this.spinner.hide();
          console.log(error);
        })

    }
  }

  
  open(content) {
    this.modalService.open(content);
  }
}
