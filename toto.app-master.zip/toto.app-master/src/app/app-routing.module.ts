import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SigninComponent } from './signin/signin.component';
import { UserComponent } from './user/user.component';
import { UserDetailComponent } from './user/user-detail/user-detail.component'; 
import { BlacklistComponent } from './user/blacklist/blacklist.component';
import { GamesComponent } from './games/games.component';
import { GamesEditComponent } from './games/games-edit/games-edit.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { TransactionComponent } from './transaction/transaction.component';
import { PasaranSettingComponent } from './pasaran-setting/pasaran-setting.component';
import { PasaranSettingDetailComponent } from './pasaran-setting/pasaran-setting-detail/pasaran-setting-detail.component';
import { PeriodComponent } from './period/period.component';
import { PeriodDetailComponent } from './period/period-detail/period-detail.component'; 
import { InputComponent } from './input/input.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { PeriodDetailPlayerComponent } from './period/period-detail-player/period-detail-player.component';
import { PeriodDetailGamesComponent } from './period/period-detail-games/period-detail-games.component';
import { BankComponent } from './bank/bank.component';
import { PendingComponent } from './pending/pending.component';
import { InboxComponent } from './inbox/inbox.component';
import { InboxReadComponent } from './inbox/inbox-read/inbox-read.component';
import { AuthGuard } from './guard/auth.guard';
import { NotFoundComponent } from './not-found/not-found.component';
import { ShioComponent } from './shio/shio.component';
import { AdminComponent } from './admin/admin.component';
import { ProfileComponent } from './profile/profile.component';
import { RenewpassComponent } from './renewpass/renewpass.component';
import { ReportComponent } from './report/report.component';
import { InfoComponent } from './info/info.component';
import { GameslinkComponent } from './gameslink/gameslink.component';
import { GameslinkDetailComponent } from './gameslink/gameslink-detail/gameslink-detail.component';
import { PeriodDetailTransactioncodeComponent } from './period/period-detail-transactioncode/period-detail-transactioncode.component';

const routes: Routes = [
  { path: '', component: SigninComponent }, 
  { path: 'renewpass/:token', component: RenewpassComponent }, 
  { path: 'signin', component: SigninComponent },  

  { path: 'dashboard', component: DashboardComponent,  canActivate: [AuthGuard] },  
  { path: 'info', component: InfoComponent, canActivate: [AuthGuard] }, 
  
  { path: 'user', component: UserComponent, canActivate: [AuthGuard] , data : {moduleId : "3"} }, 
  { path: 'blacklist', component: BlacklistComponent, canActivate: [AuthGuard] , data : {moduleId : "3"} }, 
  
  { path: 'user/:id', component: UserDetailComponent, canActivate: [AuthGuard] , data : {moduleId : "3"} },    

  { path: 'admin', component: AdminComponent, canActivate: [AuthGuard]  , data : {moduleId : "100"} }, 
  { path: 'admin/:id', component: UserDetailComponent, canActivate: [AuthGuard], data : {moduleId : "100"} },    

  { path: 'profile', component: ProfileComponent, canActivate: [AuthGuard] , data : {moduleId : "100"} },    

  { path: 'ps', component: PasaranSettingComponent, canActivate: [AuthGuard],  data : {moduleId : "7"} }, 
  { path: 'ps/detail/:id', component: PasaranSettingDetailComponent, canActivate: [AuthGuard],  data : {moduleId : "7"} },  

  { path: 'period', component: PeriodComponent, canActivate: [AuthGuard],  data : {moduleId : "4"} }, 
  { path: 'period/:id', component: PeriodComponent, canActivate: [AuthGuard],  data : {moduleId : "4"} },  
  { path: 'period/detail/:id', component: PeriodDetailComponent, canActivate: [AuthGuard],  data : {moduleId : "4"} }, 
  { path: 'period/detail/player/:periodId/:userId', component: PeriodDetailPlayerComponent, canActivate: [AuthGuard],  data : {moduleId : "4"} }, 
  { path: 'period/transaction/:transactionCode', component: PeriodDetailTransactioncodeComponent, canActivate: [AuthGuard],  data : {moduleId : "4"} }, 
  
  { path: 'period/detail/games/:periodId/:userId', component: PeriodDetailGamesComponent, canActivate: [AuthGuard],  data : {moduleId : "4"} },

  { path: 'shio', component: ShioComponent, canActivate: [AuthGuard],  data : {moduleId : "13"} },  

  { path: 'pending', component: PendingComponent, canActivate: [AuthGuard],  data : {moduleId : "6"} },  

  { path: 'inbox', component: InboxComponent, canActivate: [AuthGuard],  data : {moduleId : "9"} }, 
  { path: 'inbox/read/:uuid', component: InboxReadComponent, canActivate: [AuthGuard],  data : {moduleId : "9"} },  

  { path: 'transaction', component: TransactionComponent, canActivate: [AuthGuard],  data : {moduleId : "8"} },   
  { path: 'input', component: InputComponent, canActivate: [AuthGuard],  data : {moduleId : "5"} },   

  { path: 'games', component: GamesComponent, canActivate: [AuthGuard],  data : {moduleId : "12"} }, 
  { path: 'games/edit/:id', component: GamesEditComponent, canActivate: [AuthGuard],  data : {moduleId : "12"} },  

  { path: 'gameslink', component: GameslinkComponent, canActivate: [AuthGuard],  data : {moduleId : "14"} }, 
  { path: 'gameslink/detail/:id', component: GameslinkDetailComponent, canActivate: [AuthGuard],  data : {moduleId : "14"} }, 
 


  { path: 'bank', component: BankComponent, canActivate: [AuthGuard],  data : {moduleId : "11"} },  

  { path: 'report', component: ReportComponent, canActivate: [AuthGuard],  data : {moduleId : "10"} },  
  { path: 'deposit', component: DepositComponent, canActivate: [AuthGuard],  data : {moduleId : "1"} }, 
  { path: 'withdraw', component: WithdrawComponent, canActivate: [AuthGuard],  data : {moduleId : "2"} }, 


  { path: '**', component: NotFoundComponent },  
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
