import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { ConfigService } from 'src/app/service/config.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  accessRight : any = []; 
  constructor(
    private configService: ConfigService, 
    private router: Router
  ){ }

  canActivate(activeRoute: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean 
  { 
    this.accessRight = this.configService.accessRight(activeRoute.data['moduleId']);  
    if(this.configService.getToken() && this.accessRight['_access'] ){
      return true;
    }else{
      this.router.navigate(['/notFound']);
      return false;

    }
   
  }
  
}
