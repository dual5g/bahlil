import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ConfigService } from 'src/app/service/config.service';
import { environment } from 'src/environments/environment';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgxSpinnerService } from "ngx-spinner";
import * as $ from 'jquery';
import * as Feather from 'feather-icons';

export class Account {
  constructor(
    public id_user_access: string,
    public email: string,
    public name: string,
    public password: string,
  ) { }
}

declare var $;
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss']
})
export class AdminComponent implements OnInit {
  model: any = new Account("", "", "","");
  items: any = [];
  constructor(
    private http: HttpClient,
    private router: Router,
    private configService: ConfigService,
    private spinner: NgxSpinnerService,
    config: NgbModalConfig, private modalService: NgbModal
  ) {
    config.backdrop = 'static';
    config.keyboard = false;
  }

  ngOnInit(): void {
    Feather.replace();
    this.httpGet();
  }


  httpGet() {
    this.spinner.show();
    this.http.get<any>(environment.api + 'admin/', {
      headers: this.configService.headers()
    }).subscribe(
      data => {

        this.spinner.hide();
        this.items = data['admin'];
      }, error => {
        this.spinner.hide();
        console.log(error);
        alert("Error Server Connnection !");
      })
  }

  open(content) {
    this.modalService.open(content);
  }


  onSubmit() {
    this.spinner.show();
    this.modalService.dismissAll();
    this.http.post<any>(environment.api + 'admin/onSubmit', this.model, {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        console.log(data);
        this.httpGet();
        this.model = new Account("", "", "", "");
      }, error => {
        console.log(error);
      });

  }

  remove(items) {

    if (confirm("Delete " + items['name'] + " ?")) {
      this.spinner.show();
      const body = {
        id: items['id'],
      }
      this.http.post<any>(environment.api + 'user/remove/', body, {
        headers: this.configService.headers()
      }).subscribe(
        () => {
          this.httpGet();
        }, error => {
          alert("ERROR REMOVE()");
          this.spinner.hide();
          console.log(error);
        })


    }
  }

  accountDetail: any;
  newPassword: string;
  resetPassModal(content, obj) {
    this.accountDetail = obj;
    this.modalService.open(content);
  }

  resetPassword() {

    this.spinner.show();
    const body = {
      newPassword: this.newPassword,
      accountDetail : this.accountDetail,
    }
    this.http.post<any>(environment.api + 'admin/resetPassword/', body, {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        console.log(data); 
        this.spinner.hide();
        this.accountDetail  = null;
        this.newPassword = null;
        this.modalService.dismissAll();
      }, error => {
        alert("ERROR REMOVE()");
        this.spinner.hide();
        console.log(error);
      })

  }

}
