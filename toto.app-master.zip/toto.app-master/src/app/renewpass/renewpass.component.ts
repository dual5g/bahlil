import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { CookiesService } from 'src/app/service/cookies.service';
import { ConfigService } from '../service/config.service';
import { NgxSpinnerService } from "ngx-spinner";
import { Md5 } from "md5-typescript";

export class Renew {
  constructor(
    public password: string,
  ) { }
}

@Component({
  selector: 'app-renewpass',
  templateUrl: './renewpass.component.html',
  styleUrls: ['./renewpass.component.scss']
})
export class RenewpassComponent implements OnInit {
  model: any = new Renew('');
  token : string;
  constructor(
    private http: HttpClient,
    private cookies: CookiesService,
    private configService: ConfigService,
    private spinner: NgxSpinnerService, 
    private activatedRoute: ActivatedRoute,
  ) { }
 
  ngOnInit(): void {
    this.token = this.activatedRoute.snapshot.paramMap.get('token'); 
  }

  onSubmit() {
    this.spinner.show();
  
    const body = {
      items : Md5.init( this.model['password']),
      token : this.token
    }
    this.http.post<any>(environment.api + 'login/renewpassword/', body).subscribe(
      data => {
      
        if(!data['error']){
          this.configService.logout(); 
          setTimeout(function(){ 
            window.location.href = environment.base_url;
           }, 1000);
        }else{
          alert("ERROR");
        }
       
      }, error => {
        console.log(error);
        this.spinner.hide();
      })
  }


  test() {
    if (this.cookies.getCookie('totoBamboV1')) {

      this.configService.logout();
    }
  }


}
