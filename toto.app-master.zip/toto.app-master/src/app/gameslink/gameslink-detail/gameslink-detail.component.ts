import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gameslink-detail',
  templateUrl: './gameslink-detail.component.html',
  styleUrls: ['./gameslink-detail.component.scss']
})
export class GameslinkDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
