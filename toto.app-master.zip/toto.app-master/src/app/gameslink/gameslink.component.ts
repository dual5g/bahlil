import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ConfigService } from 'src/app/service/config.service';
import { environment } from 'src/environments/environment';

import { NgxSpinnerService } from "ngx-spinner";
import * as Feather from 'feather-icons';

declare var $;


@Component({
  selector: 'app-gameslink',
  templateUrl: './gameslink.component.html',
  styleUrls: ['./gameslink.component.scss']
})
export class GameslinkComponent implements OnInit {

  items: any = [];
  detail: any = [];

  constructor(
    private http: HttpClient,
    private router: Router,
    private configService: ConfigService,
    private spinner: NgxSpinnerService
  ) { }

  ngOnInit(): void {
    Feather.replace();
    this.httpGet();
  }

  httpGet() {
    this.spinner.show();
    this.http.get<any>(environment.api + 'gameslink', {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        console.log(data);
        this.items = data['data'];
        $('.modal').modal('hide');
        this.spinner.hide();
      }, error => {
        console.log(error);
        this.spinner.hide();
      })
  }

  onInsert() {
    const body = {
      data: "new",
    }
    this.spinner.show();
    this.http.post<any>(environment.api + 'gameslink/onInsert/', body, {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        console.log(data); 
        this.httpGet();
      }, error => {
        console.log(error);
        this.spinner.hide();
      })
  }

  onUpdate(){
    this.spinner.show();
    this.http.post<any>(environment.api + 'gameslink/onUpdate/', this.detail, {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        console.log(data);
        this.httpGet();
      }, error => {
        console.log(error);
        this.spinner.hide();
      })
  }

  onDelete() { 
    const body = {
      id: this.detail['id'],
    }
    this.spinner.show();
    this.http.post<any>(environment.api + 'gameslink/onDelete/', body, {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        console.log(data);
        this.httpGet();

      }, error => {
        console.log(error);
        this.spinner.hide();
      })
  }

}
