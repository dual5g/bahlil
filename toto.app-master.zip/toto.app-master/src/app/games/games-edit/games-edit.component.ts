import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { ConfigService } from 'src/app/service/config.service';
import { environment } from 'src/environments/environment';
import * as Feather from 'feather-icons';

export class Model {
  constructor(
    public name: string,
    public rules: string,
    public prize: string,
    public prizeLabel: string,
    public discount: number,
    public allowDuplicated: string,
    public limitBet: string, 
    public status: string,
    public sorting: string,
 
    public cms: string,
 
  ) { }
}

@Component({
  selector: 'app-games-edit',
  templateUrl: './games-edit.component.html',
  styleUrls: ['./games-edit.component.scss']
})
export class GamesEditComponent implements OnInit {
  model: any = [];
  apiKey : string = environment.apiKey;
  tinyConfig: any = environment.tinyConfig;
  loading:boolean=false;
  id: string;
  currency: string = "Rp ";
  constructor(
    private http: HttpClient,
    private router: Router,
    private configService: ConfigService,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit(): void {
    this.id = this.activatedRoute.snapshot.paramMap.get('id');
    Feather.replace();
    this.httpGet();
  }
  httpGet() {
    this.http.get<any>(environment.api + 'games/edit/'+this.id, {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        console.log(data);
    
        this.model = new Model(
          data['name'],
          data['rules'],
          data['prize'],
          data['prizeLabel'],
          parseFloat(data['discount']) * 100,
          data['allowDuplicated'],
          data['limitBet'],
          data['status'],
          data['sorting'],
          data['cms']); 
      }, error => {
        console.log(error);
      })
  }

  onSubmit(){
    const body = {
      id : this.id,
      data : this.model,
    }
    this.loading = true;
    this.http.post<any>(environment.api + 'games/update/',body, {
      headers: this.configService.headers()
    }).subscribe(
      data => { 
        console.log(data);
        this.loading = false;
      }, error => {
        console.log(error);
        this.loading = false;
      })
  }

}
