import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { ConfigService } from 'src/app/service/config.service';
import { environment } from 'src/environments/environment';
import * as Feather from 'feather-icons';

@Component({
  selector: 'app-games',
  templateUrl: './games.component.html',
  styleUrls: ['./games.component.scss']
})
export class GamesComponent implements OnInit {
  items: any = []; 
  
  id:string;
  currency : string = "Rp ";
  constructor(
    private http: HttpClient,
    private router: Router,
    private configService: ConfigService,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit(): void {
    this.id= this.activatedRoute.snapshot.paramMap.get('id');
    Feather.replace();
    this.httpGet(); 
  }
  httpGet() {
    this.http.get<any>( environment.api+'games/',{
      headers: this.configService.headers()
    }).subscribe(
      data=>{
        console.log(data);  
        this.items = data['data'];   
        
      },error=>{
        console.log(error);
      })
  }

}
