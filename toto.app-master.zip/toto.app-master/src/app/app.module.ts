import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CurrencyMaskConfig, CurrencyMaskModule, CURRENCY_MASK_CONFIG } from 'ng2-currency-mask';
import { NgbPaginationModule, NgbAlertModule } from '@ng-bootstrap/ng-bootstrap';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxSpinnerModule } from "ngx-spinner";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ConnectionServiceModule } from 'ngx-connection-service';
import { ChartsModule } from 'ng2-charts'; 

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SigninComponent } from './signin/signin.component';
import { UserComponent } from './user/user.component';
import { LeftNavComponent } from './global/left-nav/left-nav.component';
import { TopNavComponent } from './global/top-nav/top-nav.component';
import { UserDetailComponent } from './user/user-detail/user-detail.component'; 
import { BlacklistComponent } from './user/blacklist/blacklist.component';
import { GamesComponent } from './games/games.component';
import { GamesEditComponent } from './games/games-edit/games-edit.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { TransactionComponent } from './transaction/transaction.component';
import { MarketComponent } from './market/market.component';
import { PasaranSettingComponent } from './pasaran-setting/pasaran-setting.component';
import { PasaranSettingDetailComponent } from './pasaran-setting/pasaran-setting-detail/pasaran-setting-detail.component';
import { PeriodComponent } from './period/period.component';
import { PeriodDetailComponent } from './period/period-detail/period-detail.component';
import { InputComponent } from './input/input.component';

import { DashboardComponent } from './dashboard/dashboard.component';
import { PeriodDetailPlayerComponent } from './period/period-detail-player/period-detail-player.component';
import { PeriodDetailGamesComponent } from './period/period-detail-games/period-detail-games.component';
import { BankComponent } from './bank/bank.component';
import { PendingComponent } from './pending/pending.component';
import { InboxComponent } from './inbox/inbox.component';
import { InboxReadComponent } from './inbox/inbox-read/inbox-read.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { ShioComponent } from './shio/shio.component';
import { AdminComponent } from './admin/admin.component';
import { AdminDetailComponent } from './admin/admin-detail/admin-detail.component';
import { ProfileComponent } from './profile/profile.component';
import { RenewpassComponent } from './renewpass/renewpass.component';
import { ReportComponent } from './report/report.component';
import { InfoComponent } from './info/info.component';
import { EditorModule } from '@tinymce/tinymce-angular';
import { GameslinkComponent } from './gameslink/gameslink.component';
import { GameslinkDetailComponent } from './gameslink/gameslink-detail/gameslink-detail.component';
import { PeriodDetailTransactioncodeComponent } from './period/period-detail-transactioncode/period-detail-transactioncode.component';

export const CustomCurrencyMaskConfig: CurrencyMaskConfig = {
  align: "right",
  allowNegative: true,
  decimal: ",",
  precision: 0,
  prefix: "Rp ",
  suffix: "",
  thousands: "."
};


@NgModule({
  declarations: [
    AppComponent,
    SigninComponent,
    UserComponent,
    LeftNavComponent,
    TopNavComponent,
    UserDetailComponent, 
    BlacklistComponent,
    GamesComponent,
    GamesEditComponent,
    DepositComponent,
    WithdrawComponent,
    TransactionComponent,
    MarketComponent,
    PasaranSettingComponent,
    PasaranSettingDetailComponent,
    PeriodComponent,
    PeriodDetailComponent,
    InputComponent,
    DashboardComponent,
    PeriodDetailPlayerComponent,
    PeriodDetailGamesComponent,
    BankComponent,
    PendingComponent,
    InboxComponent,
    InboxReadComponent,
    NotFoundComponent,
    ShioComponent,
    AdminComponent,
    AdminDetailComponent,
    ProfileComponent,
    RenewpassComponent,
    ReportComponent,
    InfoComponent,
    GameslinkComponent,
    GameslinkDetailComponent,
    PeriodDetailTransactioncodeComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    CurrencyMaskModule,
    NgbModule,
    NgbPaginationModule, NgbAlertModule,
    BrowserAnimationsModule,
    ConnectionServiceModule,
    NgxSpinnerModule,
    ChartsModule,
    EditorModule
    
  ],
  providers: [
    { provide: CURRENCY_MASK_CONFIG, useValue: CustomCurrencyMaskConfig }
  ],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class AppModule { }
