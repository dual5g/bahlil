import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ConfigService } from 'src/app/service/config.service';
import { environment } from 'src/environments/environment';

import { NgxSpinnerService } from "ngx-spinner";
import * as Feather from 'feather-icons';

declare var $;

export class Model {
  constructor(
    public name: string,
    public code: string,
    public closedHourStart: string,
    public closedHourEnd: string,
    public su: string,
    public mo: string,
    public tu: string,
    public we: string,
    public th: string,
    public fr: string,
    public sa: string,
  ) { }
}

@Component({
  selector: 'app-pasaran-setting',
  templateUrl: './pasaran-setting.component.html',
  styleUrls: ['./pasaran-setting.component.scss']
})
export class PasaranSettingComponent implements OnInit {
  items: any = [];
  model:any = [];
  id: string;
  currency: string = "Rp ";
  loading : boolean = false;
  constructor(
    private http: HttpClient,
    private router: Router,
    private configService: ConfigService, 
    private spinner: NgxSpinnerService
  ) { }

  ngOnInit(): void {
    Feather.replace();
    this.httpGet();
    this.model = new Model("","","","","","","","","","","");
  }
  
  httpGet() {
    this.spinner.show();
    this.http.get<any>(environment.api + 'pasaran/', {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        console.log(data);
        this.items = data['data'];   
        this.spinner.hide();
      },error=>{
        console.log(error);
        this.spinner.hide();
      })
  }

  onEnable(data) {
    
    const body = {
      id : data['id'],
      status : data['status']
    }
    this.http.post<any>(environment.api + 'pasaran/onEnable/', body, {
      headers: this.configService.headers()
    }).subscribe(
      data => { 
        console.log(data);
      }, error => {
        console.log(error);
      })
  }


  onSubmit(){
    const body = { 
      data : this.model,
    }
    this.loading = true;
    this.http.post<any>(environment.api + 'pasaran/insert/',body, {
      headers: this.configService.headers()
    }).subscribe(
      data => { 
        console.log(data);
        $('.modal').modal('hide');

        this.router.navigate(['/ps/detail',data['id']]);
        this.loading = false;
      }, error => {
        console.log(error);
        this.loading = false;
      })
  }


}
