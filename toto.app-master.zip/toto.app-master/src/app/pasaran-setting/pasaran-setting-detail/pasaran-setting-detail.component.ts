import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { ConfigService } from 'src/app/service/config.service';
import { environment } from 'src/environments/environment';

import { NgxSpinnerService } from "ngx-spinner";
import * as Feather from 'feather-icons';

export class Model {
  constructor(
    public name: string,
    public code: string,
    public closedHourStart: string,
    public closedHourEnd: string,
    public status: number,

    public Sunday: string,
    public Monday: string,
    public Tuesday: string,
    public Wednesday: string,
    public Thursday: string,
    public Friday: string,
    public Saturday: string,

    public periodNumber: number,
    public periodDate: any,

    public url: string,
    public icon: string,
    public star: string,
    public note: string,
    public note2: string,
    public sorting: string,

  ) { }
}
@Component({
  selector: 'app-pasaran-setting-detail',
  templateUrl: './pasaran-setting-detail.component.html',
  styleUrls: ['./pasaran-setting-detail.component.scss']
})
export class PasaranSettingDetailComponent implements OnInit {
  resetDate: string = "";
  model: any = [];
  loading: boolean = false;
  id: string;
  currency: string = "Rp ";
  error: boolean = false;
  lock: boolean = true;
  apiKey: string = environment.apiKey;
  tinyConfig: any = environment.tinyConfig;
  note: string;
  lastPeriod: string;
  constructor(
    private http: HttpClient,
    private configService: ConfigService,
    private activatedRoute: ActivatedRoute,
    private spinner: NgxSpinnerService
  ) { }

  ngOnInit(): void {
    this.id = this.activatedRoute.snapshot.paramMap.get('id');
    Feather.replace();
    this.httpGet();
  }
  httpGet() {
    this.spinner.show();
    this.http.get<any>(environment.api + 'pasaran/detail/' + this.id, {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        console.log(data);
        this.lock = data['lock'];
        this.error = data['error'];
        this.resetDate = data['data']['resetDate'];
        this.lastPeriod = data['lastPeriod'];
        this.model = new Model(
          data['data']['name'],
          data['data']['code'],
          data['data']['closedHourStart'],
          data['data']['closedHourEnd'],
          data['data']['status'],

          data['data']['Sunday'],
          data['data']['Monday'],
          data['data']['Tuesday'],
          data['data']['Wednesday'],
          data['data']['Thursday'],
          data['data']['Friday'],
          data['data']['Saturday'],

          data['periodNumber'],
          data['periodDate'],
          data['data']['url'],
          data['data']['icon'],
          data['data']['star'],
          data['data']['note'],
          data['data']['note2'],
          data['data']['sorting'],

        );
        this.spinner.hide();
      }, error => {
        console.log(error);
        this.spinner.hide();
      })
  }

  onSubmit() {
   
    this.spinner.show();
    const body = {
      id: this.id,
      data: this.model,
      error: this.error
    }
    console.log(body);
    this.loading = true;
    this.http.post<any>(environment.api + 'pasaran/update/', body, {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        this.note = 'Update Done';
        console.log(data);
        this.httpGet();

      }, error => {
        console.log(error);
        this.spinner.hide();
      })
  }

  onDays(days) {
    if (this.model[days] == '1') {
      this.model[days] = '0';
    } else {
      this.model[days] = '1';
    }
  }


}
