import { Component, OnInit, Input, EventEmitter } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ConfigService } from 'src/app/service/config.service';
import { environment } from 'src/environments/environment';
import { ConnectionService } from 'ngx-connection-service';

import * as Feather from 'feather-icons';

@Component({
  selector: 'app-top-nav',
  templateUrl: './top-nav.component.html',
  styleUrls: ['./top-nav.component.scss']
})
export class TopNavComponent implements OnInit {

  @Input() private onReceive: EventEmitter<boolean>;

  serverTime: any;
  dbTime: any;
  today: any = new Date();
  hasNetworkConnection: boolean;
  hasInternetAccess: boolean;
  status: boolean = true;
  interval :any;
  i: number = 1000;

  notif : any = [];
  inbox : number = 0;
  constructor(
    private http: HttpClient,
    private configService: ConfigService,
    private activatedRoute: ActivatedRoute,
    private connectionService: ConnectionService, 
    private router :Router,
  ) {

    this.connectionService.monitor().subscribe(currentState => {
      this.hasNetworkConnection = currentState.hasNetworkConnection;
      this.hasInternetAccess = currentState.hasInternetAccess;
      if (this.hasNetworkConnection && this.hasInternetAccess) {
        this.status = true;
      } else {
        this.status = false;
      }
    });

  }
   
 
  ngOnInit(): void {
    Feather.replace();
    this.configService.extenCookies();
    // setTimeout(function(){
    //   window.location.href='/';
    //   console.log("Auto Refresh");
    // }, 60 * 60 * 1000);
    if (this.onReceive) {
      this.onReceive.subscribe(data => {
        // Do something in the childComponent after parent emits the event.
        console.log('this.uploadSuccess.subscribe ');
        this.httpGet();
      });
    }
    
    this.httpGet();  
    
  }
  access(id:string){
    return this.configService.accessRight(id)['_access'];
  }
  clock(obj) {
    // var oldDateObj = new Date();
    var getTimeServer = new Date(obj['ServerTime']).getTime();
    var getDbTime = new Date(obj['dbTime']['now']).getTime();
    
    setInterval(() => {
      this.i += 1000;

      this.today = new Date();
      this.serverTime = new Date(getTimeServer + this.i); 
      this.dbTime = new Date(getDbTime + this.i); 
 
    }, 1000);
  }

  httpGet() {
    this.http.get<any>(environment.api + 'setting/top', {
      headers: this.configService.headers()
    }).subscribe(
      data => { 
        this.notif = data['notif'];
        this.inbox = data['inbox']['total'];
        
        this.serverTime = new Date(data['ServerTime']);
        this.clock(data);
        this.dbTime = data['dbTime']['now'];
      }, error => {
        console.log(error);
      })
  }


  logout(){ 
    const body = [];
    this.http.post<any>( environment.api+'user/logout', body,{
      headers: this.configService.headers()
    }).subscribe(
      () =>{
       this.configService.logout(); 
        
        window.location.href=  environment.base_url;

      },error=>{
        console.log(error);
      });
  }

  
}
