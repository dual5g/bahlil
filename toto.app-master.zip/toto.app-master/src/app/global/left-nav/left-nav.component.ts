import { Component, OnInit, EventEmitter, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ConfigService } from 'src/app/service/config.service';
import { environment } from 'src/environments/environment';
import * as Feather from 'feather-icons';
declare var $;

@Component({
  selector: 'app-left-nav',
  templateUrl: './left-nav.component.html',
  styleUrls: ['./left-nav.component.scss']
})
export class LeftNavComponent implements OnInit {
  @Input() private onReceive: EventEmitter<boolean>;

  accessRight : any;
  items: any = {
    deposit: 0,
    withdraw: 0,
    inbox: 0,
  };
  current: string = "";
  constructor(
    private http: HttpClient,
    private configService: ConfigService,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit(): void {

    if (this.onReceive) {
      this.onReceive.subscribe( () => { 
        this.httpGet();
      });
    }


    this.current = this.activatedRoute.url['_value'][0]['path'];
    $(document).ready(function () {
      
      var body = $('body');

      // Sidebar toggle to sidebar-folded
      $('.sidebar-toggler').on('click', function (e) {
        $(this).toggleClass('active');
        $(this).toggleClass('not-active');
        if (window.matchMedia('(min-width: 992px)').matches) {
          e.preventDefault();
          body.toggleClass('sidebar-folded');
        } else if (window.matchMedia('(max-width: 991px)').matches) {
          e.preventDefault();
          body.toggleClass('sidebar-open');
        }
      });


      // close sidebar when click outside on mobile/table    
      $(document).on('click touchstart', function (e) {
        e.stopPropagation();

        // closing of sidebar menu when clicking outside of it
        if (!$(e.target).closest('.sidebar-toggler').length) {
          var sidebar = $(e.target).closest('.sidebar').length;
          var sidebarBody = $(e.target).closest('.sidebar-body').length;
          if (!sidebar && !sidebarBody) {
            if ($('body').hasClass('sidebar-open')) {
              $('body').removeClass('sidebar-open');
            }
          }
        }
      }); 

    });

    this.httpGet(); 
   
  }

  access(id:string){
    return this.configService.accessRight(id)['_access'];
  }

  httpGet() {
    this.http.get<any>(environment.api + 'setting/', {
      headers: this.configService.headers()
    }).subscribe(
      data => { 
        this.items = {
          deposit: parseInt(data['deposit']['total']),
          withdraw: parseInt(data['withdraw']['total']),
          pending: parseInt(data['pending']['total']),

          inbox: parseInt(data['inbox']['total']),
        };

      }, error => {
        console.log(error);
      })
  }

 
}
