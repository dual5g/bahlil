import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http'; 
import { ConfigService } from 'src/app/service/config.service';
import { environment } from 'src/environments/environment';
import * as Feather from 'feather-icons';
@Component({
  selector: 'app-shio',
  templateUrl: './shio.component.html',
  styleUrls: ['./shio.component.scss']
})
export class ShioComponent implements OnInit {
  shio_date: any = []; 
  shio: any = []; 
  editable: boolean = false;
  year : number = new Date().getFullYear();
  curYear : number = new Date().getFullYear();
  
  constructor(
    private http: HttpClient, 
    private configService: ConfigService, 
  ) { }

  ngOnInit(): void {
    Feather.replace();
    this.httpGet(); 
  }
  httpGet() {
    this.http.get<any>( environment.api+'games/shio',{
      headers: this.configService.headers()
    }).subscribe(
      data=>{
        console.log(data);  
        //this.year = data['year'];
        this.shio_date = data['shio_date'];   
        this.shio = data['shio'];   
       
      },error=>{
        console.log(error);
      })
  }


  updateShio(add = 1){
    var shioDate = this.shio_date; 

    if((this.year - this.curYear) + add < 0) add =0;

    this.year = this.year + add;
    var tempShio; 
    shioDate.forEach( (value,index) =>{
    

      tempShio =  parseInt(this.shio_date[index]['shioId'])  + add;
      tempShio = (tempShio % 12) > 0 ? tempShio % 12 : tempShio;
   
      if(tempShio == 0) tempShio = 12;
      this.shio_date[index]['shioId'] = tempShio;
    } );

  }

  updateDb(){
    const body ={ 
      year :this.year,
      shio_date : this.shio_date 
    }
    this.http.post<any>( environment.api+'games/shioUpdate', body, {
      headers: this.configService.headers()
    }).subscribe(
      data=>{
        console.log(data);   
      },error=>{
        console.log(error);
      })
    
  }
}
