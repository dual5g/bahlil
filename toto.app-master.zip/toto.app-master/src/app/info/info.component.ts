import { Component, OnInit, HostListener } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PlatformLocation } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { ConfigService } from 'src/app/service/config.service';
import { environment } from 'src/environments/environment';

import { NgxSpinnerService } from "ngx-spinner";
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap'; 

declare var $;


export class Info {

  constructor(
    public title: string,
    public note: string,
    public expiredDate: any,

  ) { }

}

@Component({
  selector: 'app-info',
  templateUrl: './info.component.html',
  styleUrls: ['./info.component.scss']
})
export class InfoComponent implements OnInit {
  info :any = [];
  model : any;
  apiKey : string = environment.apiKey;
  note : string;
  tinyConfig: any = environment.tinyConfig;
  constructor(
    private http: HttpClient,
    private router: Router,
    private configService: ConfigService,
    private activatedRoute: ActivatedRoute,
    location: PlatformLocation,
    config: NgbModalConfig, private modalService: NgbModal,
    private spinner: NgxSpinnerService,
  ) { }

  ngOnInit(): void {
    this.httpGet();

  }

  httpGet() {
    this.model = new Info("","","");
    this.spinner.show();
    this.http.get<any>(environment.api + 'info/', {
      headers: this.configService.headers()
    }).subscribe(
      data => { 
        this.info = data['info'];
        this.note = data['note']; 
        this.spinner.hide();
      }, error => {
        console.log(error);
        this.spinner.hide();
      })
  }

  open(content) { 
    this.modalService.open(content);
  }

  onSubmit(){
    this.spinner.show();
    this.http.post<any>(environment.api + 'info/onSubmit', this.model , {
      headers: this.configService.headers()
    }).subscribe(
      () => { 
        this.httpGet();
        this.modalService.dismissAll();
      }, error => {
        console.log(error);
        this.spinner.hide();
      })
  }

  onDelete(x){
    console.log(x);
    this.spinner.show();
    this.http.post<any>(environment.api + 'info/onDelete', { id :x.id} , {
      headers: this.configService.headers()
    }).subscribe(
      () => { 
        this.httpGet(); 
      }, error => {
        console.log(error);
        this.spinner.hide();
      })
  }

  fnNoteUpdate(){ 
    this.spinner.show();
    const body = {
      value :  this.note,
    }
    this.http.post<any>(environment.api + 'info/fnNoteUpdate', body , {
      headers: this.configService.headers()
    }).subscribe(
      data => { 
        console.log(data);
        this.spinner.hide();
      }, error => {
        console.log(error);
        this.spinner.hide();
      })
  }


}
