import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { NgxSpinnerService } from "ngx-spinner";
import { Router, ActivatedRoute } from '@angular/router';
import { ConfigService } from 'src/app/service/config.service';
import { environment } from 'src/environments/environment';
import * as Feather from 'feather-icons';


import { ChartOptions, ChartType, ChartDataSets } from 'chart.js';
import { Label } from 'ng2-charts';
import { PlatformLocation } from '@angular/common';

declare var $;

@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.scss']
})
export class ReportComponent implements OnInit {
  loading: boolean = false;
  report: any = [];
  pasaran: any = [];
  pasaranSelect: any = [];
  select: any = [];
  cashin: number;
  lost: number;
  profit:number;


  barChartOptions: ChartOptions = {
    responsive: true,
    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true,
          callback: function (value, index, values) {
            var n = +value;
            if ((n - Math.floor(n)) === 0) {
              return value;
            }
          },
        }
      }],
    },
  };
  barChartType: ChartType = 'line';
  barChartLegend = true;
  barChartPlugins = [];

  barChartLabels: Label[] = [];
  barChartData: ChartDataSets[] = [
    { data: [], label: 'Loading' },
  ];

 

  constructor(
    private http: HttpClient,
    private router: Router,
    private configService: ConfigService,
    private activatedRoute: ActivatedRoute,
    location: PlatformLocation,
    private spinner: NgxSpinnerService,
  ) {
    location.onPopState(() => {
      $('.modal').modal('hide');
    });

  }

  ngOnInit(): void {
    Feather.replace();
    this.httpGet(); 
  }

  httpGet() {
    this.spinner.show();
    this.loading = true;

    this.http.get<any>(environment.api + 'dashboard/cash', {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        console.log(data);
        this.spinner.hide();
        this.report = data['report'];
        this.loading = false;
        
        this.cashin  = data['cashin'];
        this.lost  = data['lost'];
        this.profit  = data['profit'];

        this.onChart(data['report']);
      }, error => {
        this.spinner.hide();
        console.log(error);
        alert("Error Server Connnection !");
      });
    
  }
  
  onChart(data) {
     

    this.barChartLabels = data.map(elm => { return elm['date']; });
    this.barChartData = [
      {
        data:data.map(elm => { return parseInt(elm['cash']) / 1000000 ; }),
        label: "x Million",
        backgroundColor: 'rgba(54, 162, 235, 0.1)',
        hoverBackgroundColor: 'rgba(54, 162, 235, 0.9)',
      },
    ];
  }
 
 
  
}
