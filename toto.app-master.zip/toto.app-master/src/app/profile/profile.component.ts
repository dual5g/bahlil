import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { ConfigService } from 'src/app/service/config.service';
import { environment } from 'src/environments/environment';
import * as Feather from 'feather-icons';
import { NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { NgxSpinnerService } from "ngx-spinner";
import { PlatformLocation } from '@angular/common';
import {Md5} from "md5-typescript";

declare var $;

export class Model {
  constructor(
    public name: string,
    public username: string,
    public email: string,
    public phone: string,
  ) { }
}
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {
  model: any = [];
  loading: boolean = false;
  id: string;
  currency: string = "Rp ";
  password : any = {
    old : "",
    new : "",
    newConfirm : ""
  }
  constructor(
    private http: HttpClient,
    private router: Router,
    private configService: ConfigService,
    private activatedRoute: ActivatedRoute,
    location: PlatformLocation,
    private spinner: NgxSpinnerService,
    private modalService: NgbModal
  ) {
    location.onPopState(() => {
      $('.modal').modal('hide');
    });

  }

  ngOnInit(): void {
    this.id = this.activatedRoute.snapshot.paramMap.get('id');
    Feather.replace();
    this.httpGet();
  }
  httpGet() {
    this.loading = true;
    this.spinner.show();
    this.http.get<any>(environment.api + 'admin/profile/', {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        console.log(data);

        this.model = new Model(
          data['profile']['name'],
          data['profile']['username'],
          data['profile']['email'],
          data['profile']['phone']);
        this.loading = false;
        this.spinner.hide();
      }, error => {

        console.log(error);
        this.spinner.hide();
      })
  }

  open(content) {
    this.modalService.open(content)}

  onSubmit() {
    this.spinner.show();
    this.loading = true;
    this.http.post<any>(environment.api + 'admin/updateProfile/', this.model, {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        console.log(data);
        this.loading = false;
        this.spinner.hide();
      }, error => {

        console.log(error);
        this.spinner.hide();
      })
  }

  updatePassword(){
    const body = {
      old : Md5.init(this.password['old']),
      new : Md5.init(this.password['new']),
      newConfirm : Md5.init(this.password['newConfirm']),
    }

    this.spinner.show();
    this.http.post<any>(environment.api + 'admin/updatePassword/', body,  {
      headers: this.configService.headers()
    }).subscribe(
      data => { 
        if(data['error']){
          alert("Wrong Old Password ! Please Try Again");
        }else{
          this.password = {
            old : "",
            new : "",
            newConfirm : ""
          } 
          this.loading = false;
        }
        this.modalService.dismissAll();
        this.spinner.hide();
      
      }, error => { 
        console.log(error);
        alert("ERROR updatePass();");
        this.spinner.hide();
      })
   
  }


}
