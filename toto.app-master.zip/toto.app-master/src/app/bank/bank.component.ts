import { Component, OnInit, HostListener } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';

import { HttpClient } from '@angular/common/http';
import { PlatformLocation } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { ConfigService } from 'src/app/service/config.service';
import { environment } from 'src/environments/environment';

import { NgxSpinnerService } from "ngx-spinner";
import * as Feather from 'feather-icons';

import * as $ from 'jquery';


declare var $;



@Component({
  selector: 'app-bank',
  templateUrl: './bank.component.html',
  styleUrls: ['./bank.component.scss']
})
export class BankComponent implements OnInit {
  bank: any = [];
  editable: boolean = false;
  deposit: any = {
    min: 0,
    max: 0,
    note: "",
  }
  withdraw: any = {
    min: 0,
    max: 0,
    note: "",
  }
  content: any;
  constructor(
    private http: HttpClient,
    private router: Router,
    private configService: ConfigService,
    private activatedRoute: ActivatedRoute,
    location: PlatformLocation,
    private spinner: NgxSpinnerService,
    private domSanitizer: DomSanitizer,
  ) {
    location.onPopState(() => {
      $('.modal').modal('hide');
    });

  }

  ngOnInit(): void {
    this.content = this.domSanitizer.bypassSecurityTrustHtml("<h1>hahah</h1> <p>123 </p>");
    Feather.replace();
    this.httpGet();
  }

  updateBankAcces(){
    return this.configService.accessRight("11")['_insert'];
  }

  httpGet() {
    this.spinner.show();
    this.http.get<any>(environment.api + 'bank/', {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        console.log(data);
        this.spinner.hide();
        this.bank = data['bank'];
        this.deposit = {
          min: data['deposit']['min'],
          max: data['deposit']['max'],
          note: data['deposit']['note'],
        }
        this.withdraw = {
          min: data['withdraw']['min'],
          max: data['withdraw']['max'],
          note: data['withdraw']['note'],
        }
      }, error => {
        this.spinner.hide();
        console.log(error);
        alert("Error Server Connnection !");
      })
  }
  updateGlobal() {
    this.http.post<any>(environment.api + 'bank/updateGlobal', {
      deposit: this.deposit,
      withdraw: this.withdraw,
    }, {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        console.log(data);
        this.httpGet();
      }, error => {
        console.log(error);
        alert("Error Server Connnection !");
      })
  }

  update(obj) {
    console.log(obj);
    this.http.post<any>(environment.api + 'bank/update', obj, {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        console.log(data);
        this.httpGet();
      }, error => {
        console.log(error);
        alert("Error Server Connnection !");
      })
  }

  onNewBank() {
    var scrollingElement = (document.scrollingElement || document.body);
    this.http.post<any>(environment.api + 'bank/onNewBank',
      {
        bank: "New Bank",
      }, {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        console.log(data);
       
        scrollingElement.scrollTop = scrollingElement.scrollHeight + 1000;
        this.httpGet();
      }, error => {
        console.log(error);
        alert("Error Server Connnection !");
      })
  }

  delete(obj) {
    if (confirm("Delete this bank " + obj['bank'] + " ?")) {
      console.log(obj);
      this.http.post<any>(environment.api + 'bank/delete', obj, {
        headers: this.configService.headers()
      }).subscribe(
        data => {
          console.log(data);
          this.httpGet();
        }, error => {
          console.log(error);
          alert("Error Server Connnection !");
        })
    }
  }

}
