import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { ConfigService } from 'src/app/service/config.service';
import { environment } from 'src/environments/environment'; 
import { NgxSpinnerService } from "ngx-spinner";
import {Md5} from "md5-typescript";
import * as Feather from 'feather-icons';
 

export class ModelPass {

  constructor( 
    public password: string, 
  ) {  }

}


@Component({
  selector: 'app-period-detail',
  templateUrl: './period-detail.component.html',
  styleUrls: ['./period-detail.component.scss']
})
export class PeriodDetailComponent implements OnInit {
  period: any = []; 
  detail: any = []; 
  players : any = [];
  id:string;
  currency : string = "Rp ";
  games : any = [];
  loading:boolean = false;
  market : any = [];
  disable:boolean = true;
  modelPass : any = new ModelPass("");
  tab: string;
  constructor(
    private http: HttpClient,
    private router: Router,
    private configService: ConfigService,
    private activatedRoute: ActivatedRoute,
    private spinner: NgxSpinnerService,
  ) { 

    this.activatedRoute.queryParams.subscribe(params => {
      this.tab = params['tab'];
      console.log(this.tab); // Print the parameter to the console. 
  });
  }

  ngOnInit(): void { 
    Feather.replace();
  
    this.id = this.activatedRoute.snapshot.paramMap.get('id');
    this.httpGet( this.id ); 
    
  }
  httpGet(id) {
    this.spinner.show();
    this.http.get<any>( environment.api+'period/detail/'+id,{
      headers: this.configService.headers()
    }).subscribe(
      data=>{
        console.log(data);    
        this.market = data['market'];
        this.games = data['games'];
        this.period = data['period'];
        this.players = data['players'];
        this.spinner.hide();
       },error=>{

        console.log(error);
        this.spinner.hide();
      })
  }
  access(){
    return this.configService.accessRight("4");
  }

  onMarket(){
    this.router.navigate(['/period/detail/',this.id]);
    this.httpGet(this.id); 
  }
 
  onUpdateResult(){
    this.spinner.show();
    const body = {
      periodId  : this.id,
      password : Md5.init(this.modelPass['password']) ,
      result : this.period['result']
    }
 
    this.http.post<any>( environment.api+'period/onUpdateResult/', body,{
      headers: this.configService.headers()
    }).subscribe(
      data=>{
        console.log(data);  
        if(data['error'] == false){
          this.modelPass = new ModelPass("");
          this.disable = true;
          this.spinner.hide();
        }else{
          this.spinner.hide();
          alert("Error,Wrong Password !");
        }
       },error=>{
        this.spinner.hide();
        console.log(error);
      });
  }
}
