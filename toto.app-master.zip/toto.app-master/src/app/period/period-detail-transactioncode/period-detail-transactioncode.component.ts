import { Component, OnInit, HostListener } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PlatformLocation } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { ConfigService } from 'src/app/service/config.service';
import { environment } from 'src/environments/environment';
import * as Feather from 'feather-icons';

import { NgxSpinnerService } from "ngx-spinner";

declare var $;
@Component({
  selector: 'app-period-detail-transactioncode',
  templateUrl: './period-detail-transactioncode.component.html',
  styleUrls: ['./period-detail-transactioncode.component.scss']
})
export class PeriodDetailTransactioncodeComponent implements OnInit {
  period: any = [];
  user: any = [];
  marketId: string;
  periodId: string;
  currency: string = "Rp ";
  market: string;
  pasaran: any = [];
  loading: boolean = false;
  status: boolean = false;
  games: any = [];
  userId: string;
  total: any = [];
  gamesBetting: any = [];
  transactionCode: string;
  presence : boolean = true;
  constructor(
    private http: HttpClient,
    private router: Router,
    private configService: ConfigService,
    private activatedRoute: ActivatedRoute,
    location: PlatformLocation,
    private spinner: NgxSpinnerService,
  ) {
    location.onPopState(() => {
      $('.modal').modal('hide');
    });

  }

  ngOnInit(): void {
    this.transactionCode = this.activatedRoute.snapshot.paramMap.get('transactionCode');
    Feather.replace();
    this.httpGet(this.transactionCode);
  }

  httpGet(periodId) {
    this.spinner.show();
    this.loading = true;
    console.log(environment.api + 'period/transaction/' + this.transactionCode);
    this.http.get<any>(environment.api + 'period/transaction/' + this.transactionCode, {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        this.loading = false;;
        if (data['error'] == 400) {
          console.log(data);
        } else {
          this.presence = data['presence'];
 
          this.pasaran = data['pasaran'];
          this.market = data['market'];
          this.period = data['period'];
          this.user = data['user'];
          this.status = data['status'];
          this.total = 0;
          this.games = data['games'];
          this.currency = "Rp";
          this.gamesBetting = data['gamesBetting'];
        }
        this.spinner.hide();

      }, error => {

        console.log(error);
        this.spinner.hide();
      })
  }

  onModal(market) {
    this.market = market;
  }

  onDelete() {
    if (confirm("Waring! Delete transaction " + this.transactionCode + "? ")) {

      this.spinner.show();
      const body = {
        transactionCode: this.transactionCode
      }
      this.http.post<any>(environment.api + 'period/deleteTransaction/', body, {
        headers: this.configService.headers()
      }).subscribe(
        data => {
          this.loading = false;
          window.history.back();
          this.spinner.hide();
        }, error => {
          console.log(error);
          this.spinner.hide();
        });
    }
  }
  back() {
    window.history.back();
  }

}
