import { Component, OnInit, HostListener } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PlatformLocation } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { ConfigService } from 'src/app/service/config.service';
import { environment } from 'src/environments/environment';
import * as Feather from 'feather-icons';

import { NgxSpinnerService } from "ngx-spinner";
import { ChartOptions, ChartType, ChartDataSets } from 'chart.js';
import { Label } from 'ng2-charts';


declare var $;

@Component({
  selector: 'app-period-detail-games',
  templateUrl: './period-detail-games.component.html',
  styleUrls: ['./period-detail-games.component.scss']
})
export class PeriodDetailGamesComponent implements OnInit {
  period: any = [];
  player: any = [];
  marketId: string;
  periodId: string;
  currency: string = "Rp ";
  market: any = [];
  pasaran: any = [];
  loading: boolean = false;
  status: boolean = false;
  games: any = [];
  gamesId: string;
  total: any = [];
  number : any = [];
  barChartOptions: ChartOptions = {
    responsive: true,
    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true,
          callback: function (value, index, values) {  
            var n = +value; 
            if ((n - Math.floor(n)) === 0) {
              return value;
            } 
          },
        }
      }],
    },
  };
  barChartType: ChartType = 'bar';
  barChartLegend = true;
  barChartPlugins = [];

  barChartLabels: Label[] = [];
  barChartData: ChartDataSets[] = [
    { data: [], label: 'Loading' },
  ];
  select: any = [];

  showCart : boolean = false;


  constructor(
    private http: HttpClient,
    private router: Router,
    private configService: ConfigService,
    private activatedRoute: ActivatedRoute,
    location: PlatformLocation,
    private spinner: NgxSpinnerService,
  ) {
    location.onPopState(() => {
      $('.modal').modal('hide');
    });

  }

  ngOnInit(): void {
    this.periodId = this.activatedRoute.snapshot.paramMap.get('periodId');
    this.gamesId = this.activatedRoute.snapshot.paramMap.get('userId');

    Feather.replace();
    this.httpGet(this.gamesId);
    this.httpSelect();
  }

  httpGet(gamesId) {
    this.spinner.show();
    this.loading = true;

    this.http.get<any>(environment.api + 'period/detailGames/' + this.periodId + '/' + gamesId, {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        this.loading = false;
        this.gamesId = data['gamesId'];

        if( this.gamesId == '3') this.showCart = true;
        else if( this.gamesId == '4') this.showCart = true;
        else if( this.gamesId == '5') this.showCart = true;
        

        this.pasaran = data['pasaran'];
        this.market = data['market'];
        this.period = data['period'];
        this.status = data['status'];
        this.total = data['total'];
        this.games = data['games'];
        this.player = data['player'];
        this.number = data['number'];
        this.barChartLabels = data['number'].map(elm => {  
          return  elm['bettingNumber'] == data['period']['resultByGames'] ? 'Win:'+elm['bettingNumber'] : elm['bettingNumber']; 
        });
        this.barChartData = [
          {
            data: data['number'].map(elm => { return parseInt(elm['total']); }),
            label: data['games']['rules'] + ' ' + data['market']['name'],
            backgroundColor: 'rgba(54, 162, 235, 0.5)',
            hoverBackgroundColor: 'rgba(54, 162, 235, 0.9)',
          },
        ];
        console.log(data);
        console.log(this.barChartLabels);


        this.spinner.hide();
      }, error => {

        console.log(error);
        this.spinner.hide();
      })
  }

  onMarket() {
    this.router.navigate(['/period/detail/games/', this.periodId, this.gamesId]);
    this.httpGet(this.gamesId);
  }

  httpSelect() {
    this.loading = true;
    this.http.get<any>(environment.api + 'games/index/', {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        this.select = data;
        this.loading = false;
      }, error => {
        console.log(error);
      })
  }





}
