import { Component, OnInit, HostListener } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PlatformLocation } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { ConfigService } from 'src/app/service/config.service';
import { environment } from 'src/environments/environment';

import { NgxSpinnerService } from "ngx-spinner";
import * as Feather from 'feather-icons';

import * as $ from 'jquery';
declare var $;

@Component({
  selector: 'app-period',
  templateUrl: './period.component.html',
  styleUrls: ['./period.component.scss']
})
export class PeriodComponent implements OnInit {

  period: any = [];
  games: any = [];
  id: string;
  currency: string = "Rp ";
  market: any = [];
  pasaran: string;
  loading: boolean = false;
  constructor(
    private http: HttpClient,
    private router: Router,
    private configService: ConfigService,
    private activatedRoute: ActivatedRoute,
    location: PlatformLocation,
    private spinner: NgxSpinnerService,
  ) {
    location.onPopState(() => {
      $('.modal').modal('hide');
    });

  }

  ngOnInit(): void {
    Feather.replace();
    this.id = this.activatedRoute.snapshot.paramMap.get('id');
    this.httpGet(this.id);
    this.httpSelect();
   
  }

  access(){
    return this.configService.accessRight("4");
  }

  onMarket() {
    this.router.navigate(['/period/', this.id]);
    this.httpGet(this.id);
  }

  httpGet(id) {
    this.loading = true;
    this.spinner.show();
    this.http.get<any>(environment.api + 'period/index/' + id, {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        console.log(data);
        this.pasaran = data['pasaran'];
        this.period = data['period'];
        $(document).ready(function () {
          $.fn.dataTable.ext.errMode = 'none';
          $('#dtable').DataTable(
            { "bSort": false },
          );
        });
        this.loading = false;
        this.spinner.hide();
      }, error => {

        console.log(error);
        this.spinner.hide();
      })
  }

  httpSelect() {
    this.loading = true;

    this.http.get<any>(environment.api + 'pasaran/index/', {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        this.market = data['data'];

        this.loading = false;
      }, error => {
        console.log(error);
      })
  }

  onRemove(x) {
    console.log(x);
    if (confirm('Delete this period  ' + x.periodNumber + ' ?')) {
      this.spinner.show();
      this.http.post<any>(environment.api + 'period/onRemove/', x, {
        headers: this.configService.headers()
      }).subscribe(
        data => {
          this.market = data['data'];
          this.router.navigateByUrl('/', { skipLocationChange: true }).then(() =>
            this.router.navigate(['period',this.id])
          );
          this.loading = false;
        }, error => {
          console.log(error);
        });
    }
  }

}
