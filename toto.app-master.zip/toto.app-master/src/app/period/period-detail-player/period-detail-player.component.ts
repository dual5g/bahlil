import { Component, OnInit, HostListener } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PlatformLocation } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { ConfigService } from 'src/app/service/config.service';
import { environment } from 'src/environments/environment';
import * as Feather from 'feather-icons';

import { NgxSpinnerService } from "ngx-spinner";


declare var $;
@Component({
  selector: 'app-period-detail-player',
  templateUrl: './period-detail-player.component.html',
  styleUrls: ['./period-detail-player.component.scss']
})
export class PeriodDetailPlayerComponent implements OnInit {
  period: any = [];
  user: any = [];
  marketId: string;
  periodId: string;
  currency: string = "Rp ";
  market: string;
  pasaran: any = [];
  loading: boolean = false;
  status: boolean = false;
  games: any = [];
  userId: string;
  total: any = [];
  transaction : any = [];
  gamesBetting : any = [];
  constructor(
    private http: HttpClient,
    private router: Router,
    private configService: ConfigService,
    private activatedRoute: ActivatedRoute,
    location: PlatformLocation, 
    private spinner: NgxSpinnerService,
  ) {
    location.onPopState(() => {
      $('.modal').modal('hide');
    });

  }

  ngOnInit(): void {
    this.periodId = this.activatedRoute.snapshot.paramMap.get('periodId');
    this.userId = this.activatedRoute.snapshot.paramMap.get('userId');

    Feather.replace();
    this.httpGet(this.periodId);
  }
 
  httpGet(periodId) {
    this.spinner.show();
    this.loading = true;
    console.log(environment.api + 'period/detailPlayer/' + periodId + '/' + this.userId);
    this.http.get<any>(environment.api + 'period/detailPlayer/' + periodId + '/' + this.userId, {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        this.loading = false;;
        if(data['error'] == 400){
          console.log(data);
          alert(data['note']);
          this.router.navigate(['transaction']);
        }else{
          this.pasaran = data['pasaran'];
          this.market = data['market'];
          this.period = data['period'];
          this.user = data['user'];
          this.status = data['status'];
          this.total = data['total'];
          this.transaction = data['transaction']
          this.games = data['games'];
          this.gamesBetting = data['gamesBetting'];
        }
      
        
        this.spinner.hide();
       
      },error=>{

       console.log(error);
       this.spinner.hide();
     })
  }


  onDelete(code){
    if(confirm("Warning !! Delete this transaction "+code) ){

    }
  }
  onModal(market) {
    this.market = market;
  }

}
