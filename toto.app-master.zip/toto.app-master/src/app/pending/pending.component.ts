import { Component, OnInit, HostListener, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PlatformLocation } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { ConfigService } from 'src/app/service/config.service';
import { environment } from 'src/environments/environment';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgxSpinnerService } from "ngx-spinner";
import * as Feather from 'feather-icons';

import * as $ from 'jquery';
declare var $;

@Component({
  selector: 'app-pending',
  templateUrl: './pending.component.html',
  styleUrls: ['./pending.component.scss']
})
export class PendingComponent implements OnInit {
  onEmit: EventEmitter<boolean> = new EventEmitter();

  inputResult: any = {
    result: null,
  }
  period: any = [];
  games: any = [];
  currency: string = "Rp ";
  market: any = [];
  pasaran: string;
  loading: boolean = false;
  constructor(
    private http: HttpClient,
    private router: Router,
    private configService: ConfigService,
    private activatedRoute: ActivatedRoute,
    location: PlatformLocation,
    private spinner: NgxSpinnerService,
    config: NgbModalConfig, private modalService: NgbModal
  ) {
    config.backdrop = 'static';
    config.keyboard = false;
    location.onPopState(() => {
      $('.modal').modal('hide');
    });

  }

  ngOnInit(): void {
    Feather.replace();
    this.httpGet();
  }

  httpGet() {
    this.loading = true;
    this.spinner.show();
    this.http.get<any>(environment.api + 'pending/', {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        this.period = data['period'];
        $(document).ready(function () {
          $.fn.dataTable.ext.errMode = 'none';
          $('#dtable').DataTable(
            { "bSort": false },
          );
        });
        this.loading = false;
        this.spinner.hide();
      }, error => {

        console.log(error);
        this.spinner.hide();
      })
  }

  onCancel(x) {
    if (confirm("Cancel '" + x.market + "' period " + x.periodNumber + " ? ")) {
      this.spinner.show();
      this.http.post<any>(environment.api + 'pending/onCancel/', x, {
        headers: this.configService.headers()
      }).subscribe(
        () => {
          this.onEmit.emit(true);
          this.httpGet();
        }, error => {
          console.log(error); alert("Error ! onCancel();");
        })
    }
  }

 
  onInput(content, obj) { 
    this.inputResult =  {
      id: obj['marketId'],
      name: obj["market"],
      code: obj["code"],
      status: true, 
      periodId: obj['id'],  
      periodNumber : obj['periodNumber'],  
      periodDate : obj['periodDate'],
      totalPlayer  : obj["totalPlayer"],
      totalBetting : obj["totalBet"],
      result: null,
      pending: false
    } 
    this.modalService.open(content, { size: 'sm' });
    document.getElementById("inputResult").focus();
  }


  onSubmitResult() {
   
    var items = [];
    items.push(this.inputResult);
    console.log(items);
    if (confirm("Hati-hati! Submit final result pasaran data tidak bisa dirollback? ")) {
      
      this.spinner.show();
      this.http.post<any>(environment.api + 'pending/onSubmitResult/', this.inputResult, {
        headers: this.configService.headers()
      }).subscribe(
        data => { 
          this.modalService.dismissAll();
          this.onEmit.emit(true);
          this.httpGet(); 
        }, error => {
          this.loading = false;
          alert("Error Server ! onSubmitResult(); "); 
          console.log(error);
        })

    }

  }

}
