import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { NgxSpinnerService } from "ngx-spinner";
import { Router, ActivatedRoute } from '@angular/router';
import { ConfigService } from 'src/app/service/config.service';
import { environment } from 'src/environments/environment';
import * as Feather from 'feather-icons';


import { ChartOptions, ChartType, ChartDataSets } from 'chart.js';
import { Label } from 'ng2-charts';
import { PlatformLocation } from '@angular/common';

declare var $;

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  loading: boolean = false;
  bank: any = [];
  pasaran: any = [];
  pasaranSelect: any = [];
  select: any = [];


  barChartOptions: ChartOptions = {
    responsive: true,
    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true,
          callback: function (value, index, values) {
            var n = +value;
            if ((n - Math.floor(n)) === 0) {
              return value;
            }
          },
        }
      }],
    },
  };
  barChartType: ChartType = 'bar';
  barChartLegend = true;
  barChartPlugins = [];

  barChartLabels: Label[] = [];
  barChartData: ChartDataSets[] = [
    { data: [], label: 'Loading' },
  ];


  barPriceOptions: ChartOptions = {
    responsive: true,
    tooltips: {
      enabled: true,
      // callbacks: {
      //   title: function (tooltipItem, data) {
      //     console.log(tooltipItem['index']);
      //     console.log(data);
      //     return "tetete";
      //   },

      //   label: function (tooltipItem, data) {
      //     return "hahahaha"
      //   }
      // }
    },
    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true,
          callback: function (value, index, values) {
            var n = +value;
            if ((n - Math.floor(n)) === 0) {
              return value + "k";
            }
          },
        },
      }],
    },
  };
  barPriceType: ChartType = 'bar';
  barPriceLegend = true;
  barPricePlugins = [];
  barPriceLabels: Label[] = [];
  barPriceData: ChartDataSets[] = [
    { data: [], label: 'Loading' },
  ];

  constructor(
    private http: HttpClient,
    private router: Router,
    private configService: ConfigService,
    private activatedRoute: ActivatedRoute,
    location: PlatformLocation,
    private spinner: NgxSpinnerService,
  ) {
    location.onPopState(() => {
      $('.modal').modal('hide');
    });

  }

  ngOnInit(): void {
    Feather.replace();
    this.httpGet();
    this.httpPasaran();
  }

  httpGet() {
    this.spinner.show();
    this.loading = true;

    this.http.get<any>(environment.api + 'dashboard/', {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        this.spinner.hide();
        this.bank = data['bank'];
        this.loading = false;
      }, error => {
        this.spinner.hide();
        console.log(error);
        alert("Error Server Connnection !");
      });
    this.updateOnlineBank();
  }

  updateOnlineBank() {
    setInterval(() => {
      this.http.get<any>(environment.api + 'dashboard/', {
        headers: this.configService.headers()
      }).subscribe(
        data => {
          this.bank = data['bank'];
        }, error => {
          console.log("SERVER ERROR updateOnlineBank() ");
        })
    }, 60000);

  }

  httpPasaran() {

    this.http.get<any>(environment.api + 'pasaran/index', {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        this.pasaran = data['data'];
        this.pasaranSelect = this.pasaran[0];
        this.onChangeMarket();
      }, error => {
        this.spinner.hide();
        console.log(error);
        alert("Error Server Connnection !");
      })
  }

  onChangeMarket() {
    this.onBar2D(this.pasaranSelect);
    this.onBarByPrice(this.pasaranSelect);

  }

  onBar2D(x) {
    this.loading = true;
    this.http.get<any>(environment.api + 'period/detailGames/' + x.periodId + '/3', {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        this.loading = false;
        this.barChartLabels = data['number'].map(elm => {
          return elm['bettingNumber'] == data['period']['resultByGames'] ? 'Win:' + elm['bettingNumber'] : elm['bettingNumber'];
        });
        this.barChartData = [
          {
            data: data['number'].map(elm => { return parseInt(elm['total']); }),
            label: data['games']['rules'] + ' ' + data['market']['name'],
            backgroundColor: 'rgba(54, 162, 235, 0.5)',
            hoverBackgroundColor: 'rgba(54, 162, 235, 0.9)',
          },
        ];
        this.spinner.hide();
      }, error => {

        console.log(error);
        this.spinner.hide();
      })

  }

  onBarByPrice(x) {
    this.loading = true;
    this.http.get<any>(environment.api + 'period/detailGamesbyPrice/' + x.periodId + '/3', {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        this.loading = false;
        this.barPriceLabels = data['number'].map(elm => {
          return elm['bettingNumber'] == data['period']['resultByGames'] ? 'Win:' + elm['bettingNumber'] : elm['bettingNumber'];
        });
        this.barPriceData = [
          {
            data: data['number'].map(elm => { return parseInt(elm['total']); }),
            label: data['games']['rules'] + ' ' + data['market']['name'],
            backgroundColor: 'rgba(54, 162, 235, 0.5)',
            hoverBackgroundColor: 'rgba(54, 162, 235, 0.9)',
          },
        ];


        this.spinner.hide();
      }, error => {

        console.log(error);
        this.spinner.hide();
      })

  }

}
