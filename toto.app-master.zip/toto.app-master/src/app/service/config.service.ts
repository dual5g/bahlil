import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { CookiesService } from './cookies.service';

@Injectable({
  providedIn: 'root'
})
export class ConfigService {

  varKey: string = "mXTSxrEKSErYnZb33LyBus5RpVtGNfcgEBqxp5Unk5azj4ZgdWfhkfVDKJ3KSLFG7DtecSehXe7Q67NGFWGehU3ANexas3ZbrkfU";
  varToken: string;
  varHeaders: any = [];
  rules: any;
  varData: any = [];
  constructor(
    private http: HttpClient,
    private cookies: CookiesService,
  ) {

    if (this.cookies.getCookie('totoBamboV1') == null) {
      //window.location.href = this.login();
      console.log("tidak ada session login");
    } else {
      this.varToken = this.cookies.getCookie('totoBamboV1');

    }

  }

  logout() {
    document.cookie = "totoBamboV1=null; expires = Thu, 01 Jan 1970 00:00:00 GMT;path=/";
    document.cookie = "totoBamboV1Access=null; expires = Thu, 01 Jan 1970 00:00:00 GMT;path=/";

  }

  getToken() {
    return this.cookies.getCookie('totoBamboV1');
  }

  username() {
    return this.varData['name'];
  }

  headers() {

    return this.varHeaders = new HttpHeaders({
      'Content-Type': 'application/json',
      'Key': this.varKey,
      'Token': this.varToken,
    });
  }

  key() {
    return this.varKey;
  }
  token() {
    return this.varToken;
  }

  id_user() {
    return this.varToken;
  }


  errorToken(data) {
    if (data['error'] == 400) {
      //  window.location.href = "login";
    }

  }


  extenCookies() {
     
    var d = new Date();
    d.setTime(d.getTime() + (24*60*60*1000));
    var expires = "expires=" + d.toUTCString();
    document.cookie = 'totoBamboV1' + "=" + this.cookies.getCookie('totoBamboV1') + ";" + expires + ";path=/";
    document.cookie = 'totoBamboV1Access' + "=" + this.cookies.getCookie('totoBamboV1Access') + ";" + expires + ";path=/";



  }


  module(id: string) {
    let data = [
      { id: "1", name: "deposit" },
      { id: "2", name: "withdraw" },
      { id: "3", name: "user" },
      { id: "4", name: "period" },
      { id: "5", name: "input" },
      { id: "6", name: "pending" },
      { id: "7", name: "ps" },
      { id: "8", name: "transaction" },
      { id: "9", name: "inbox" },
      { id: "10", name: "report" },
      { id: "11", name: "bank" },
      { id: "12", name: "games" },
      { id: "13", name: "shio" },
      
      { id: "100", name: "admin" }
    ];


    return data[id];

  }
  accessRightList(){
    return JSON.parse(atob(this.cookies.getCookie('totoBamboV1Access')));;
  }

  accessRight(id: string) {
    
    const openMoudule = {
      id: null,
      name: "Open Module",
      _access: true,
      _delete: false,
      _insert: false,
      _update: false,
    }

    var data = JSON.parse(atob(this.cookies.getCookie('totoBamboV1Access')));
    var objIndex = data.findIndex((obj => obj.id == id ));
    data = JSON.parse(atob(this.cookies.getCookie('totoBamboV1Access')))[objIndex];

    return id ? {
      id: data['id'],
      name: data['name'],
      _access: data['_access'] == '1' ? true : false,
      _delete: data['_delete'] == '1' ? true : false,
      _insert: data['_insert'] == '1' ? true : false,
      _update: data['_update'] == '1' ? true : false,
    } : openMoudule;
  }


}
