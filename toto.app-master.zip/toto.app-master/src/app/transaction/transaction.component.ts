import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http'; 
import { ConfigService } from 'src/app/service/config.service';
import { environment } from 'src/environments/environment';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap'; 
import { NgxSpinnerService } from "ngx-spinner";
import * as Feather from 'feather-icons';
import * as $ from 'jquery';

declare var $;

@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.scss']
})
export class TransactionComponent implements OnInit {
  transaction: any = [];
  deposit: any = [];
  withdraw:any = [];
  dateStart: NgbDateStruct;
  id: string;
  currency: string = "Rp ";
  constructor(
    private http: HttpClient, 
    private configService: ConfigService, 
    private spinner: NgxSpinnerService
  ) { }

  ngOnInit(): void { 
    Feather.replace();
    this.httpGet(); 
  }
 
  httpGet() {
    this.spinner.show();
    this.http.get<any>(environment.api + 'transaction/', {
      headers: this.configService.headers()
    }).subscribe(
      data => {
        console.log(data);
        this.spinner.hide();
        this.transaction = data['transaction'];
        this.deposit = data['deposit'];
        this.withdraw = data['withdraw'];
        $(document).ready(function () { 
          $('.dtable').DataTable( 
            { "bSort" : false }, 
          );
        });
        this.spinner.hide();
      }, error => {
        console.log(error);
        this.spinner.hide();
        alert("Error Server Connection !");
      })
  }

}
